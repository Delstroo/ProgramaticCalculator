//
//  ViewController.swift
//  CalculatorUI
//
//  Created by Delstun McCray on 8/17/21.
//

import SwiftUI

enum CalculatorButton: String {
    case zero, one, two, three, four, five, six, seven, eight, nine, decimal
    
    case equals, add, subtract, multiply, divide
    
    case ac
    
    var title: String {
        switch self {
        case .zero:
            return "0"
        case .one:
            return "1"
        case .two:
            return "2"
        case .three:
            return "3"
        case .four:
            return "4"
        case .five:
            return "5"
        case .six:
            return "6"
        case .seven:
            return "7"
        case .eight:
            return "8"
        case .nine:
            return "9"
        case .decimal:
            return "."
        case .equals:
            return "="
        case .add:
            return "+"
        case .subtract:
            return "-"
        case .multiply:
            return "x"
        case .divide:
            return "÷"
        default: return "AC"
            
        }
    }
    
    var backgroundColor: Color {
        switch self {
        case .zero, .one, .two, .three, .four, .five, .six, .seven, .eight, .nine, .decimal:
            return Color(#colorLiteral(red: 0.09019608051, green: 0, blue: 0.3019607961, alpha: 1))
        case .ac:
            return Color(.orange)
        default:
            return.red
        }
    }
    
    var textColor: Color {
        switch self {
        case .ac,.zero, .one, .two, .three, .four, .five, .six, .seven, .eight, .nine, .decimal, .multiply, .divide, .add, .subtract:
            return Color(.white)
        default:
            return .white
        }
    }
    
    var size: CGFloat {
        switch self {
        case .ac:
            return 30.0
        default:
            return 32.0
        }
    }
}//end of enum

class Global: ObservableObject {
    
    @Published var display = "0"
    
    //MARK: - Properties
    private var finishedNumber: Bool = true
    private var lastInput: CalculatorButton?
    
    private var displayAnswer: Double {
        get {
            guard let number = Double(self.display) else { fatalError("Cannot convert display label text to a Double") }
            return number
        }
        set {
            self.display = newValue.truncatingRemainder(dividingBy: 1) == 0 ?
                String(format: "%.0f", newValue) : String(newValue)
        }
    }
    private var calculator = CalculatorLogic()
    
    //MARK: - Methods
    func isLastOperator() -> Bool {
        guard let lastInput = lastInput else { return false }
        return lastInput == .divide || lastInput == .multiply || lastInput == .add || lastInput == .subtract
    }
    
    func receiveInput(calculatorButtons: CalculatorButton) {
        
        switch  calculatorButtons {
        case .ac, .divide, .subtract, .multiply, .add, .equals:
            if isLastOperator() { break }
            finishedNumber = true
            calculator.setNumber(displayAnswer)
            
            if let result = calculator.calculate(symbol: calculatorButtons) {
                displayAnswer = result
            }
            
        default:
            
            if finishedNumber {
                
                // do not duplicate zeros
                if displayAnswer == 0 && calculatorButtons == .zero { return }
                
                if calculatorButtons == .decimal {
                    self.display = "0" + calculatorButtons.title
                } else { self.display = calculatorButtons.title }
                
                finishedNumber = false
                
            } else {
                
                if calculatorButtons == .decimal {
                    
                    // check if number is whole number
                    if self.display.contains(".") { return }
                    
                    // check if number already has a decimal
                    let isInt = floor(displayAnswer) == displayAnswer
                    if !isInt { return }
                }
                self.display = self.display + calculatorButtons.title
            }
        }
        lastInput = calculatorButtons
    }
}

struct ContentView: View {
    
    @EnvironmentObject var env: Global
    
    let spacing: CGFloat = 16
    
    var buttonWidth = (UIScreen.main.bounds.width - 5 * 6) / 4
    
    let buttons: [[CalculatorButton]] = [
        [.ac],
        [.seven, .eight, .nine, .divide],
        [.four, .five, .six, .multiply],
        [.one, .two, .three, .subtract],
        [.zero, .decimal, .equals],
        
    ]
    
    var body: some View {
        
        ZStack (alignment: .bottom) {
            Color.black.edgesIgnoringSafeArea(.all)
            
            VStack (spacing: self.spacing) {
                
                HStack {
                    Spacer()
                    Text(env.display).foregroundColor(.white)
                        .font(.system(size: 100))
                        .fontWeight(.light)
                        .lineLimit(1)
                        .minimumScaleFactor(0.5)
                }.padding(.trailing).padding(.trailing, buttonWidth / 2 / 4)
                
                ForEach(buttons, id: \.self) { row in
                    HStack (spacing: self.spacing) {
                        ForEach(row, id: \.self) { button in
                            CalculatorButtonView(button: button)
                        }
                    }
                }
            }.padding(.bottom)
        }
    }
}

//MARK: - SubView

struct CalculatorButtonView: View {
    
    var button: CalculatorButton
    let spacing: CGFloat = 16
    
    let screenWidth = UIScreen.main.bounds.width
    
    @EnvironmentObject var env: Global
    
    var body: some View {
        Button(action: {
            self.env.receiveInput(calculatorButtons: self.button)
        }) {
            Text(button.title)
                .font(.system(size: button.size))
                .fontWeight(.regular)
                .frame(width: self.buttonWidth(button: button), height: (screenWidth - 5 * self.spacing)  / 4)
                .foregroundColor(button.textColor)
                .background(button.backgroundColor)
                .cornerRadius(self.buttonWidth(button: button))
                
        }
    }
    
    private func buttonWidth(button: CalculatorButton) -> CGFloat {
        if button == .zero {
            return (screenWidth - 4 * self.spacing)  / 4 * 2
        }
        return (screenWidth - 5 * self.spacing)  / 4
    }
}

//MARK: - Previews

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(Global())
    }
}
